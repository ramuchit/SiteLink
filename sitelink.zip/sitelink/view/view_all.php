<?php

class view_all {



	

	public function __construct(){



		

		add_shortcode('SELF_STORAGE',array($this,'all_storage'));

		add_action( 'wp_enqueue_scripts', array($this,'enque_script_style') );



		add_action('init',array($this,'register_session'));

		

	}

	public function register_session(){

			    if( !session_id() )

			        session_start();

			}



	public function enque_script_style(){

		wp_enqueue_style('site_bts-styles', plugin_dir_url( __FILE__ ) . 'assets/css/bootstrap.min.css' );

		wp_enqueue_style('modern_business-styles', plugin_dir_url( __FILE__ ) . 'assets/css/modern-business.css' );

		wp_enqueue_style('date_picker-styles', plugin_dir_url( __FILE__ ) . 'assets/css/bootstrap-datepicker3.min.css' );

		wp_enqueue_style('sites-styles', plugin_dir_url( __FILE__ ) . 'assets/css/styles.css' );



		wp_enqueue_script('bts_min_js', plugin_dir_url(__FILE__) . 'assets/js/bootstrap.min.js', array('jquery'));

		wp_enqueue_script('bts_datepicker_js', plugin_dir_url(__FILE__) . 'assets/js/bootstrap-datepicker.min.js', array('jquery'));

		wp_enqueue_script('my_cstm_js', plugin_dir_url(__FILE__) . 'assets/js/script.js', array('jquery'));



	}

	public function for_all($step){ 
		global $wp;
		$current_url = add_query_arg( $wp->query_string, '', home_url( $wp->request ) );
?>

	<div class="container">

		<?php if (isset($_SESSION['done'])) { ?>

	    <div class="row">

	        <div class="col-lg-12 bs-example bs-example-bg-classes">

	            <p class="bg-success text-center"><?= $_SESSION['done']; ?></p>

	        </div>

	    </div>

		<?php } ?>

		<div class="row">

    		<div class="col-lg-12">

       			 <ul class="steps">

            		<li class="<?= ($step == 1) ? 'present' : 'future' ?>">

                		<?php if ($step > 1) { ?>

                    		<a href="<?= $current_url ?>">

                    		<span>

                           		<strong>Step 1</strong>

                            	Select Storage Location

                       		 </span><i></i>

                        	</a>

		                <?php } else { ?>

		                    <span>

		                            <strong>Step 1</strong>

		                            Select Storage Location

		                        </span><i></i>

		                <?php } ?>

		           </li>

		            <li class="<?= ($step == 2) ? 'present' : 'future' ?>">

		                <?php if ($step > 2) { ?>

		                    <a href="<?= $current_url ?>"><span>

		                            <strong>Step 2</strong>

		                            Select Unit size

		                        </span><i></i></a>

		                <?php } else { ?>

		                    <span>

		                            <strong>Step 2</strong>

		                            Select Unit size

		                        </span><i></i>

		                <?php } ?>

		            </li>

		            <li class="<?= ($step == 3) ? 'present' : 'future' ?>">

		                <?php if ($step > 3) { ?>

		                    <a href="<?=$current_url  ?>">

		                        <span>

		                            <strong>Step 3</strong>

		                            Select Date

		                        </span><i></i></a>

		                <?php } else { ?>

		                    <span>

		                            <strong>Step 3</strong>

		                            Select Date

		                        </span><i></i>

		                <?php } ?>

		            </li>

		            <li class="<?= ($step == 4) ? 'present' : 'future' ?>">

		                        <span>

		                            <strong>Step 4</strong>

		                            Confirmation

		                        </span><i></i>

		            </li>

        </ul>

    </div>

</div>



<hr/>

<?php }

	public function all_storage(){

		extract($_POST);

		$data=array();

		$step=isset($step)?$step:1;

		$this->for_all($step);

		if($step==1){

			

			include( plugin_dir_path( __FILE__ ) . 'step-one.php');

		}

		elseif ($step==2) {

			$_SESSION['lo_code']= $lo_code;

			$_SESSION['lo_name']= $lo_name;

			$_SESSION['lo_address']= $lo_address;

			include( plugin_dir_path( __FILE__ ) . 'step-two.php');

		}

		elseif ($step==3) {

			if(isset($_POST['reserve'])){

				$_SESSION['type_text']="Reservation";

				$_SESSION['type']=1;

			}else{

				$_SESSION['type_text']="Rental";

				$_SESSION['type']=2;

			}

			$_SESSION['unit_id']=$unit_id;

			include( plugin_dir_path( __FILE__ ) . 'step-three.php');



		}elseif ($step==4) {



			$_SESSION['date']=$date;



			if(!isset($_SESSION['lo_code']) || !isset($_SESSION['date']) || !isset($_SESSION['unit_id']) ||  !isset($_SESSION['type']) ){

					wp_redirect('/');

					}

					

			        $_SESSION['error_status'] = false;

			        $_SESSION['error_message'] = '';

			        $data['date'] = $_SESSION['date'];

			        $data['step'] = 4;

			        $data['price'] = 0;

			        $formatted_date = date('Y-m-d', strtotime($_SESSION['date'])) . 'T' . date('H:i:s', strtotime($_SESSION['date']));

			        $sitlink=new Sitelink();

			        $info=new Data();

			        if ($_SESSION['type'] == 1) {

			            $data['type'] = 1;

			            $data['type_text'] = 'Reservation';



			            $reservation_fee_retrieve_return = $sitlink->reservation_fee_retrieve($_SESSION['lo_code']);

			            foreach ($reservation_fee_retrieve_return as $reservation_fee) {

			                $data['price'] = $data['price'] + $reservation_fee['dcTotal'];

			            }

			        } else {

			            $data['type'] = 2;

			            $data['type_text'] = 'Rental';

			            $move_in_cost_retrieve_return = $sitlink->move_in_cost_retrieve($_SESSION['lo_code'], $_SESSION['unit_id'], $formatted_date);

			            foreach ($move_in_cost_retrieve_return as $move_in_fee) {

			                $data['price'] = $data['price'] + $move_in_fee['dcTotal'];

			                $data['start_date_array'][] = strtotime($move_in_fee['StartDate']);

			                $data['end_date_array'][] = strtotime($move_in_fee['EndDate']);

			            }

			            $_SESSION['start_date']=$start_date = date('Y-m-d', min($data['start_date_array'])) . 'T' . date('H:i:s', min($data['start_date_array']));

			            $_SESSION['end_date']=$end_date = date('Y-m-d', max($data['end_date_array'])) . 'T' . date('H:i:s', max($data['end_date_array']));

			        }

			        $_SESSION['price']=$data['price'];

			        $data['site_information'] = $sitlink->get_site_information($_SESSION['lo_code']);

			        $data['unit_information'] = $sitlink->get_units_information_by_unit_id($_SESSION['lo_code'], $_SESSION['unit_id']);

			        $data['countries'] = array_merge(array('' => 'Select Country'), $info->get_countries());

			        $data['states'] = array_merge(array('' => 'Select State'), $info->get_states());

			        $data['card_types'] = $info->get_card_types();

			        $data['card_months'] = array_merge(array('' => 'Select Month'), $info->get_months());

			        $data['card_years'] = array_merge(array('' => 'Select Year'), $info->get_years());

			        $data['arr_hear_about'] = array('Select Source', 'Printed Yellow Pages', 'Google Search', 'Referral', 'Other', 'Yahoo/Bing', 'Kijiji Ads', 'YellowPages.ca', 'Twitter', 'Facebook Ads', 'Previous/Existing Tenant', 'Drive-By/Signs', 'Ambassador');

			 	//define('DATA',$data);

			    $_SESSION['data']=$data;

				include( plugin_dir_path( __FILE__ ) . 'step-four.php');

			}

			elseif ($step==5) {

				$sitelink=new Sitelink();

				$formatted_date = date('Y-m-d', strtotime($_SESSION['date'])) . 'T' . date('H:i:s', strtotime($_SESSION['date']));



				$tenant_data=array();

			    $tenant_data['lo_code'] =$_SESSION['lo_code'];

                $tenant_data['first_name'] = $first_name;

                $tenant_data['last_name'] = $last_name;

                $tenant_data['company'] = $company;

                $tenant_data['address_1'] = $address_1;

                $tenant_data['address_2'] = $address_2;

                $tenant_data['city'] = $city;

                $tenant_data['country'] = $_SESSION['data']['countries'][$country];

                $tenant_data['region'] = $region;

                $tenant_data['postal'] = $postal;

                $tenant_data['phone'] = $phone;

                $tenant_data['fax'] = $fax;

                $tenant_data['email'] = $email;

                $tenant_data['password'] = $password;



                $tenant_return = $sitelink->add_tenant($tenant_data);

                

                

               

                if ($tenant_return['rt']['Ret_Code'] > 0) {

                  if ($_SESSION['type'] == 1) {

                        $reservation_data['lo_code'] = $_SESSION['lo_code'];

                        $reservation_data['tenant_id'] = $tenant_return['data']['TenantID'];

                        $reservation_data['unit_id'] = $_SESSION['unit_id'];

                        $reservation_data['date'] = $formatted_date;

                        $reservation_data['comment'] = $comment;



                        $reservation_return = $sitelink->add_reservation($reservation_data);

                     

                        if ($reservation_return['rt']['Ret_Code'] > 0) {



                            if (number_format($_SESSION['price'], 2) > 0.00) {

                                $reservation_fee_data['lo_code'] = $_SESSION['lo_code'];

                                $reservation_fee_data['tenant_id'] = $tenant_return['data']['TenantID'];

                                $reservation_fee_data['waiting_list_id'] = $reservation_return['rt']['Ret_Code'];

                                $reservation_fee_data['card_name'] = sanitize_text_field($card_name);

                                $reservation_fee_data['card_address'] = $card_address;

                                $reservation_fee_data['card_postal'] = sanitize_text_field($card_postal);

                                $reservation_fee_data['card_number'] = sanitize_text_field($card_number);

                                $reservation_fee_data['card_cvv'] = sanitize_text_field($card_cvv);

                                $reservation_fee_data['expiration_date'] = date('Y-m-t', strtotime('1 ' . $_SESSION['data']['card_months'][$card_month]. ' ' . $_SESSION['data']['card_years'][$card_year]));

                                $reservation_fee_data['card_type'] = sanitize_text_field($card_type);



                                $reservation_fee_return = $sitelink->add_reservation_fee($reservation_fee_data);

                             



                                if ($reservation_fee_return['rt']['Ret_Code'] < 0) {

                                    $_SESSION['error_status'] = true;

                                 $_SESSION['error_message'] = $reservation_fee_return['rt']['Ret_Msg'];

                                }

                            }



                        } else {

                            $_SESSION['error_status'] = true;

                            $_SESSION['error_message'] = $reservation_return['rt']['Ret_Msg'];

                        }



                    }else {



                        $move_in_data['lo_code'] = $_SESSION['lo_code'];

                        $move_in_data['tenant_id'] = $tenant_return['data']['TenantID'];

                        $move_in_data['acc_id'] = $tenant_return['data']['sAccessCode'];

                        $move_in_data['unit_id'] = $_SESSION['unit_id'];

                        $move_in_data['start_date'] = $_SESSION['start_date'];

                        $move_in_data['end_date'] = $_SESSION['end_date'];

                        $move_in_data['amount'] = $_SESSION['price'];

                        $move_in_data['card_name'] = sanitize_text_field($card_name);

                        $move_in_data['card_address'] = sanitize_text_field($card_address);

                        $move_in_data['card_postal'] = sanitize_text_field($card_postal);

                        $move_in_data['card_number'] = sanitize_text_field($card_number);

                        $move_in_data['card_cvv'] = sanitize_text_field($card_cvv);

                        $move_in_data['expiration_date'] = date('Y-m-t', strtotime('1 ' . $_SESSION['data']['card_months'][$card_month]. ' ' . $_SESSION['data']['card_years'][$card_year]));

                        $move_in_data['card_type'] = $card_type;



                        $move_in_return = $sitelink->move_in($move_in_data);  



                        if ($move_in_return['rt']['Ret_Code'] > 0) {



                        } else {

                            	$_SESSION['error_status'] = true;

                           		 $_SESSION['error_message'] = $move_in_return['rt']['Ret_Msg'];

                        		}

                    }

                  } else {

                    $_SESSION['error_status'] = true;

                    $_SESSION['error_message'] = $tenant_return['rt']['Ret_Msg'];

               	 }

                  if ($_SESSION['error_status'] == false) {

                  	

                  	

                  	$sitelink->sendMail();



                    echo '!!! Yeah !!!<h3>You have successfully booked your ' . $_SESSION['type_text'].'</h3>';

                    echo '</br><a href="'.site_url().'">Go Back</a>';



                    session_destroy();

                    

                }else{

                	if(str_replace(' ','',$_SESSION['error_message'])==str_replace(' ','',"Invalid Tenant ID")){



                		echo "<h1>CURRENTLY SERVER NOT RESPONDING KINDLY TRY AFTER SOME TIME</h1>";

                		echo '</br><a href="'.site_url().'">Go Home</a>';

                	}

                	

                }

 

			} else{}

	}

}

new view_all();