<?php
/*plugin name: SiteLink Integration For SelfStorage
*/
require( plugin_dir_path( __FILE__ ) . 'inc/constant_cred.php');
require( plugin_dir_path( __FILE__ ) . 'inc/sitelink.php');
require( plugin_dir_path( __FILE__ ) . 'inc/Data.php');
require( plugin_dir_path( __FILE__ ) . 'view/view_all.php');

add_action('admin_menu', 'my_menu_pages');
function my_menu_pages(){
    add_menu_page('My Page Title', 'SiteLink', 'manage_options', 'siteLink_setting', 'my_menu_output' );
    //add_submenu_page('siteLink_stting', 'Submenu Page Title', 'Setting', 'manage_options', 'Setting' );
    //add_submenu_page('my-menu', 'Submenu Page Title2', 'Whatever You Want2', 'manage_options', 'my-menu2' );
}
function my_menu_output(){ 
	//echo get_current_user_id();
	if(isset($_POST['save_st'])){
		echo "Credential Has Been Updated";
	 	extract($_POST);

	 		update_option( 'site_mail',$site_email );
	 		update_option( 'site_url',$site_url );
	 		update_option( 'site_corp_code',$site_corp_code );
	 		update_option( 'site_loc_code',$site_loc_code );
	 		update_option('site_corp_login',$site_corp_login );
	 		update_option( 'site_corp_pwd',$site_corp_pwd );
	 	}
	 	?>
	<div class="wrap">
	<table>
	  <form method="post" action="<?php echo $_SERVER['REQUEST_URI'];?>">
	  	<tr>
		    <td>Email:</td>
		  	<td><input type="email" name="site_email" required="required" size="40" value="<?=get_option('site_mail');?>" ></td>
	  	</tr>
	  	<tr>
		  	<td>SITELINK URL:</td>
		  	<td><input type="text" name="site_url" size="40" value="<?=get_option('site_url');?>" required="required"></td>
		 </tr>
		 <tr>
		  	<td>SITELINK CORP CODE:</td>
		  	<td><input type="text" name="site_corp_code" size="40" value="<?=get_option('site_corp_code');?>" required="required"></td>
	  	</tr>
	  	<tr>
		  	<td>SITELINK LOC CODE:</td>
	        <td><input type="text" name="site_loc_code" size="40" value="<?=get_option('site_loc_code');?>" required="required"></td>
        </tr>
        <tr>
	        <td>SITELINK CORP LOGIN:</td>
	        <td><input type="text" name="site_corp_login" size="40" value="<?=get_option('site_corp_login');?>" required="required">
	        <span>Example->Administrator:::YOUR_API_KEY_HERE</span></td>
        </tr>
        <tr>
	        <td>SITELINK CORP PASSWORD:</td>
	        <td><input type="password" name="site_corp_pwd" size="40" value="<?=get_option('site_corp_pwd');?>" required="required"></td>
        </tr>
	  	<tr><td colspan="2"><input type="submit" name="save_st" value="Save" class="button button_primary"></td></tr>
	  </form>
	 </table>
		</div>
<?php  
}

//add_user_meta( $user_id, $meta_key, $meta_value, $unique );
