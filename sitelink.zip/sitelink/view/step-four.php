<?php extract($_SESSION['data']);
if ($_SESSION['error_status'] == TRUE) { ?>
    <div class="row">
        <div class="col-lg-12 bs-example bs-example-bg-classes">
            <p class="bg-danger"><?= $_SESSION['error_message']; ?></p>
        </div>
    </div>
<?php } ?>
<div class="row">
    <div class="col-lg-12">
        <h2>Storage Unit <?= $_SESSION['type_text']; ?></h2>
        <p>To complete your <?= $_SESSION['type_text']; ?>, please fill out all of the fields listed below and press the
            'Confirm <?= $_SESSION['type_text']; ?>'
            button.</p>
        <p>* = required field</p>
    </div>
</div>

<hr>

<div class="row">
    <div class="col-md-6">
        <div class="panel panel-default panel-payment">
            <div class="panel-heading">
                <h2 class="panel-title">Facility Information</h2>
            </div>
            <ul class="list-group">
                <li class="list-group-item clearfix">
                    <div class="col-md-4">Name:</div>
                    <div class="col-md-8"><strong><?php echo $site_information['sSiteName']; ?></strong></div>
                </li>
                <li class="list-group-item clearfix">
                    <div class="col-md-4">Address:</div>
                    <div class="col-md-8"><strong><?php echo $site_information['sSiteAddr1']; ?></strong></div>
                </li>
                <li class="list-group-item clearfix">
                    <div class="col-md-4">City/State/Postal:</div>
                    <div class="col-md-8"><strong><?php echo $site_information['sSiteCity']; ?>
                            <?php echo $site_information['sSiteRegion']; ?>
                            <?php echo $site_information['sSitePostalCode']; ?></strong></div>
                </li>
                <li class="list-group-item clearfix">
                    <div class="col-md-4">Phone:</div>
                    <div class="col-md-8"><strong><?php echo $site_information['sSitePhone']; ?></strong></div>
                </li>
                <!--<li class="list-group-item clearfix">
                    <div class="col-md-4">Office Hours:</div>
                    <div class="col-md-8"><strong><?php /*echo $site_information['sSiteName']; */ ?></strong></div>
                </li>-->
            </ul>
        </div>
    </div>

    <div class="col-md-6">
        <div class="panel panel-default panel-payment">
            <div class="panel-heading">
                <h2 class="panel-title">Unit &amp; Rate Information</h2>
            </div>
            <ul class="list-group">
                <li class="list-group-item clearfix">
                    <div class="col-md-4">Move-in Date:</div>
                    <div class="col-md-8"><strong><?php echo $_SESSION['date']; ?></strong></div>
                </li>
                <li class="list-group-item clearfix">
                    <div class="col-md-4">Unit Type:</div>
                    <div class="col-md-8"><strong><?php echo $unit_information['sTypeName']; ?></strong></div>
                </li>
                <li class="list-group-item clearfix">
                    <div class="col-md-4">Unit Size:</div>
                    <div class="col-md-8"><strong><?php echo number_format($unit_information['dcWidth']); ?>
                            x <?php echo number_format($unit_information['dcLength']); ?></strong></div>
                </li>
                <li class="list-group-item clearfix">
                    <div class="col-md-4"><?= ($type == 1) ? 'Reservation Fee' : 'Unit Rate'; ?>:</div>
                    <div class="col-md-8">
                        <strong>
                            <?php if (number_format($price, 2) == 0.00) { ?>
                                Free
                            <?php } else { ?>
                                <?php echo number_format($price, 2); ?> CAD
                            <?php } ?>
                            <?php if ($type != 1) { ?> / 28 days (includes 15% tax) <?php } ?>
                        </strong>
                    </div>
                </li>
                <!--<li class="list-group-item clearfix">
                    <div class="col-md-4">Total Charge:</div>
                    <div class="col-md-8"><strong><?php /*echo $site_information['sSiteName']; */ ?></strong></div>
                </li>-->
            </ul>
        </div>
    </div>


</div>

<hr>

<form action="<?php echo $_SERVER['REQUEST_URI'];?>" class="form-horizontal" method="post" accept-charset="utf-8">
<div class="row">
    <div class="col-lg-6">
        <div class="title-info">
            <h3>Contact Information</h3>
            <p>The email address and password that you enter below will be used as the log-in information for your
                storage account.</p>
        </div>
        <div class="form-group ">
            <label for="inputEmail3" class="col-sm-3 control-label">* First Name</label>
            <div class="col-sm-9">
               <input type="text" name="first_name" value="" class="form-control" required="required" placeholder="First Name">
            </div>
            
        </div>
        <div class="form-group ">
            <label for="inputEmail3" class="col-sm-3 control-label"> Last Name</label>
            <div class="col-sm-9">
                <input type="text" name="last_name" value="" class="form-control"  placeholder="Last Name">
            </div>
            
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-3 control-label">&nbsp;&nbsp;Company</label>
            <div class="col-sm-9">
                <input type="text" name="company" value="" class="form-control"  placeholder="Company">
            </div>
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-3 control-label">* Address 1</label>
            <div class="col-sm-9">
                <input type="text" name="address_1" value="" class="form-control" required="required" placeholder="Address 1">
            </div>
            
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-3 control-label">&nbsp;&nbsp;Address 2</label>
            <div class="col-sm-9">
                <input type="text" name="address_2" value="" class="form-control"  placeholder="Address 2">
            </div>
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-3 control-label">* City</label>
            <div class="col-sm-9">
               <input type="text" name="city" value="" class="form-control" required="required" placeholder="City">
            </div>
            
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-3 control-label">&nbsp;&nbsp;State/Province</label>
            <div class="col-sm-4">
              <input type="text" name="state" value="" class="form-control" placeholder="State">
            </div>
            
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-3 control-label">* Country</label>
            <div class="col-sm-9">
                <select name="country" class="form-control" required="required">
                     <?php foreach($countries as $key =>$val){
                            echo'<option value="'.$key.'" >'.$val.'</option>';
                        }?>     
                </select>
            </div>
            
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-3 control-label">&nbsp;&nbsp;Country/Region</label>
            <div class="col-sm-4">
                <input type="text" name="region" value="" class="form-control" required="required" placeholder="Region">
            </div>
            <!-- <label class="col-sm-5 control-label info-label">Required if not in US or Canada</label> -->
            
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-3 control-label">* Postal/Zip</label>
            <div class="col-sm-9">
                <input type="text" name="postal" value="" class="form-control" required="required" placeholder="Postal">
            </div>
            
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-3 control-label">* Phone</label>
            <div class="col-sm-9">
                <input type="text" name="phone" value="" class="form-control" required="required" placeholder="Phone">
            </div>
            
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-3 control-label">&nbsp;&nbsp;Fax</label>
            <div class="col-sm-9">
               <input type="text" name="fax" value="" class="form-control"  placeholder="Fax">
            </div>
        </div>
        <div class="form-group ">
            <label for="inputEmail3" class="col-sm-3 control-label">* Email</label>
            <div class="col-sm-4">
                <input type="email" name="email" value="" class="form-control" required="required" placeholder="Email">
            </div>
            <label class="col-sm-5 control-label info-label">The username for your account</label>
            
        </div>
        <div class="form-group ">
            <label for="inputEmail3" class="col-sm-3 control-label">* Password</label>
            <div class="col-sm-4">
                <input type="password" name="password" value="" class="form-control" required="required" placeholder="Password" maxlength="10" minlength="6">
            </div>
            <label class="col-sm-5 control-label info-label">Between 6 - 10 chars / numbers & letters only</label>
            
        </div>
    </div>
    <div class="col-lg-6">
        <?php if (number_format($price, 2) != 0.00) { ?>
            <div class="title-info">
                <h3>Billing Information</h3>
                <p>Enter your billing information. Make sure you have entered your credit card information
                    correctly.</p>
            </div>
            <div class="form-group ">
                <label for="inputEmail3" class="col-sm-4 control-label">* Name on Card</label>
                <div class="col-sm-8">
                    <input type="text" name="card_name" value="" class="form-control" required="required" placeholder="Name on Card">
                </div>
            </div>
            <div class="form-group ">
                <label for="inputEmail3" class="col-sm-4 control-label">* Street Address</label>
                <div class="col-sm-8">
                    <input type="text" name="card_address" value="" class="form-control" required="required" placeholder="Street Address">
                </div>
                
            </div>
            <div class="form-group ">
                <label for="inputEmail3" class="col-sm-4 control-label">* Postal/Zip</label>
                <div class="col-sm-8">
                    <input type="text" name="card_postal" value="" class="form-control" required="required" placeholder="Postal/Zip">
                </div>
                
            </div>
            <div class="form-group ">
                <label for="inputEmail3" class="col-sm-4 control-label">* Card Type</label>
                <div class="col-sm-8">
                    <select name="card_type" class="form-control" required="required">
                    <?php foreach($card_types as $key =>$val){
                            echo'<option value="'.$key.'" >'.$val.'</option>';
                        }?> 
                    </select>
                </div>
                
            </div>
            <div class="form-group ">
                <label for="inputEmail3" class="col-sm-4 control-label">* Card Number</label>
                <div class="col-sm-8">
                   <input type="text" name="card_number" value="" id="card_number" class="form-control" required="required" placeholder="Card Number">
                </div>
            </div>
            <div class="form-group ">
                <label for="inputEmail3" class="col-sm-4 control-label">* CVV Number</label>
                <div class="col-sm-8">
                    <input type="password" name="card_cvv" value="" id="cvv_number" class="form-control" required="required" >
                </div>
            </div>
            <div class="form-group ">
                <label for="inputEmail3" class="col-sm-4 control-label">* Expire Date</label>
                <div class="col-sm-4">
                     <select name="card_month" class="form-control" required="required">
                        
                        <?php foreach($card_months as $key =>$val){
                            echo'<option value="'.$key.'" >'.$val.'</option>';
                        }?>
                    </select>
                </div>
                <div class="col-sm-4">
                    <select name="card_year" class="form-control" required="required">
                       
                         <?php foreach($card_years as $key =>$val){
                            echo'<option value="'.$key.'" >'.$val.'</option>';
                        }?>    
                    </select>
                </div>
            </div>
            <h3>&nbsp;</h3>
        <?php } ?>
        <div class="title-info">
            <h3>Comments / Other Information</h3>
            <p>
                24 hours security monitoring //
                No hidden fees //
                Trusted by over 50,000 renters over 35 years //
                Easily reserve and pay for storage units online.
            </p>
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-5 control-label">&nbsp;&nbsp;Comment</label>
            <div class="col-sm-7">
                <textarea name="comment" cols="40" rows="5" class="form-control"  placeholder="Comment"></textarea>
            </div>
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-5 control-label">&nbsp;&nbsp;How did you hear about us?</label>
            <div class="col-sm-7">
                 <select name="state" class="form-control" required="required">
                        
                        <?php foreach($arr_hear_about as $key =>$val){
                            echo'<option value="'.$key.'" >'.$val.'</option>';
                        }?>    
                    </select>
            </div>
        </div>
    </div>
    <div class="col-lg-offset-6 col-lg-6">
        <input type="submit" name="confirm_btn" value="Confirm <?=$_SESSION['type_text'] ?>" class="btn btn-primary pull-right">
    </div>
</div>
<input type="hidden" name="step" value="5">
<input type="hidden" name="is_submit" value="1">
</form>