<?php $site=new Sitelink();
		$sites=$site->get_storage_locations(); 
    if(isset($sites->NewDataSet->RT->Ret_Code)):
      if($sites->NewDataSet->RT->Ret_Code < 0){
         echo '<h1>'.$sites->NewDataSet->RT->Ret_Msg.'<h1>';
      }
    endif;
	?>
	<div class="row">
       <div class="col-lg-12">
		    <?php foreach ($sites as $site): ?>
            <div class="list-group">
                <div class="list-group-item">
                    <div class="row">
                        <div class="col-lg-5">
                            <h4 class="title-site"><?php echo $site['sSiteName'] ?></h4>
                        </div>
                        <div class="col-lg-5">
                            <?php echo $site['sSiteAddr1'] ?><br/>
                            <?php echo $site['sSiteCity'] ?> <?php echo $site['sSiteRegion'] ?> <?php echo $site['sSitePostalCode'] ?>
                            <br/>
                            <strong>Tel: <?php echo $site['sSitePhone'] ?></strong>
                        </div>
                        <div class="col-lg-2 text-right">
                        	<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" accept-charset="utf-8">
                        	    <input type="hidden" name="step" value="2">
								              <input type="hidden" name="lo_code" value="<?php echo $site['sLocationCode'];?>">

								              <input type="hidden" name="lo_name" value="<?php echo $site['sSiteName'];?>">

								              <input type="hidden" name="lo_address" value="<?php echo $site['sSiteCity'] . ', ' . $site['sSiteRegion'] . ', ' . $site['sSitePostalCode'] . '<br/><strong>Tel: ' . $site['sSitePhone'] . '</strong>'; ?>">
								              <input type="submit" name="continue" value="Continue" class="btn btn-primary btn-site">
							           </form>
                          </div>
                       </div>
                   </div>
                </div>
                <?php endforeach; ?>
             </div>
		  </div>
    </div>