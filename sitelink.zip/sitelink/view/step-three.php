<div class="row">
			    <div class="col-lg-12">
			        <h2>Select <?= $_SESSION['type_text']; ?> start date</h2>
			        <p>Please click on the date that you would like to start your <?= $_SESSION['type_text']; ?>, then press the "Continue" button below to
			            enter your contact information.</p>
			    </div>
			</div>

			<hr>

			<div class="row">
			    <div class="col-lg-6 sub-title">
			        <h3><?php echo $_SESSION['lo_name']; ?></h3>
			    </div>
			    <div class="col-lg-6 text-right mobile-text">
			        <?php echo $_SESSION['lo_address']; ?>
			    </div>
			</div>

			<hr>

			<div class="row">
			    <div class="col-lg-8 col-md-offset-2">
			        <div id="rental-date" data-date=""></div>
			    </div>
			    <div class="col-lg-12">
			       
			        	<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" accept-charset="utf-8">

								<input type="hidden" name="date" id="select_date" value="">

								<input type="hidden" name="is_submit" value="<?php echo $_SESSION['type'];?>">
								<input type="hidden" name="step" value="4">
								<input type="submit" name="continue" value="Continue" class="btn btn-primary pull-right continue_3">
						</form>
			        
			    </div>
			</div>
	</div>