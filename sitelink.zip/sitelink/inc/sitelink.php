<?php
class Sitelink
{    
    public function __construct()
    {  
    }

    public function xml2array($xmlObject, $out = array())
    {
        foreach ((array)$xmlObject as $index => $node)
            $out[$index] = (is_object($node)) ? $this->xml2array($node) : $node;

        return $out;
    }

    public  function get_storage_locations()
    {   
         $client = new SoapClient(SITELINK_URL);
         $params = new stdClass();
         $params->sCorpCode = SITELINK_CORP_CODE;
         $params->sLocationCode = SITELINK_LOC_CODE;
         $params->sCorpUserName = SITELINK_CORP_LOGIN;
         $params->sCorpPassword = SITELINK_CORP_PASS;

        $params->iCountry = -999;
        $params->bMiles = false;
        $params->sPostalCode = '';

        try {
            $sites = array();
            $data = $client->SiteSearchByPostalCode($params);
            $result = $data->SiteSearchByPostalCodeResult;
            $xml_data = simplexml_load_string($result->any);
            $xml_data_table = $xml_data->NewDataSet->Table;
            if (count($xml_data_table) > 0) {
                foreach ($xml_data_table as $site) {
                    $sites[] = $this->xml2array($site);
                }
                usort($sites, function ($site1, $site2) {
                    if ($site1['SiteID'] == $site2['SiteID']) return 0;
                    return $site1['SiteID'] < $site2['SiteID'] ? -1 : 1;
                });
                return $sites;
            } else {
                return FALSE;
            }
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage() . '<br />' . $e);
        }


    }

    public function get_units_by_location_code($lo_code)
    {   
        $client = new SoapClient(SITELINK_URL);
         $params = new stdClass();
         $params->sCorpCode = SITELINK_CORP_CODE;
         $params->sLocationCode = $lo_code;
         $params->sCorpUserName = SITELINK_CORP_LOGIN;
         $params->sCorpPassword = SITELINK_CORP_PASS;
        
        try {
            $units = array();
            $data = $client->UnitTypePriceList_v2($params);
            $result = $data->UnitTypePriceList_v2Result;
            $xml_data = simplexml_load_string($result->any);
            $xml_data_table = $xml_data->NewDataSet->Table;

            if (count($xml_data_table) > 0) {
                foreach ($xml_data_table as $unit) {
                    $unit = $this->xml2array($unit);
                    if ($unit['iTotalVacant'] > 0) {
                        $units[] = $unit;
                    }
                }
                usort($units, function ($unit1, $unit2) {
                    if ($unit1['UnitTypeID'] == $unit2['UnitTypeID']) return 0;
                    return $unit1['UnitTypeID'] < $unit2['UnitTypeID'] ? -1 : 1;
                });
                return $units;
            } else {
                return FALSE;
            }
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage() . '<br />' . $e);
        }
    }

    public function get_site_information($lo_code = '')
    {   
         $client = new SoapClient(SITELINK_URL);
         $params = new stdClass();
         $params->sCorpCode = SITELINK_CORP_CODE;
         $params->sLocationCode = $lo_code;
         $params->sCorpUserName = SITELINK_CORP_LOGIN;
         $params->sCorpPassword = SITELINK_CORP_PASS;
        
        try {
            $site_information = array();
            $data = $client->SiteInformation($params);
            $result = $data->SiteInformationResult;
            $xml_data = simplexml_load_string($result->any);
            $xml_data_table = $xml_data->NewDataSet->Table;
            if (count($xml_data_table) > 0) {
                $site_information = $this->xml2array($xml_data_table);
                return $site_information;
            } else {
                return FALSE;
            }
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage() . '<br />' . $e);
        }
    }

public function get_units_information_by_unit_id($lo_code = '', $unit_id = '')
    {   
         $client = new SoapClient(SITELINK_URL);
         $params = new stdClass();
         $params->sCorpCode = SITELINK_CORP_CODE;
         $params->sLocationCode = $lo_code;
         $params->sCorpUserName = SITELINK_CORP_LOGIN;
         $params->sCorpPassword = SITELINK_CORP_PASS;
         $params->UnitID = $unit_id;
        try {
            $unit = array();
            $data = $client->UnitsInformationByUnitID($params);
            $result = $data->UnitsInformationByUnitIDResult;
            $xml_data = simplexml_load_string($result->any);
            $xml_data_table = $xml_data->NewDataSet->Table;

            if (count($xml_data_table) > 0) {
                $unit = $this->xml2array($xml_data_table);
                return $unit;
            } else {
                return FALSE;
            }
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage() . '<br />' . $e);
        }
    }

    public function add_tenant($tenant_data = array())
    {  
        $client = new SoapClient(SITELINK_URL);
        $params = new stdClass();
        $params->sCorpCode = SITELINK_CORP_CODE;
        $params->sCorpUserName = SITELINK_CORP_LOGIN;
        $params->sCorpPassword = SITELINK_CORP_PASS;

        $params->sLocationCode = $tenant_data['lo_code'];
        $params->sWebPassword = $tenant_data['password'];
        $params->sMrMrs = '';
        $params->sFName = $tenant_data['first_name'];
        $params->sMI = '';
        $params->sLName = $tenant_data['last_name'];
        $params->sCompany = $tenant_data['company'];
        $params->sAddr1 = $tenant_data['address_1'];
        $params->sAddr2 = $tenant_data['address_2'];
        $params->sCity = $tenant_data['city'];
        $params->sRegion = $tenant_data['region'];
        $params->sPostalCode = $tenant_data['postal'];
        $params->sCountry = $tenant_data['country'];
        $params->sPhone = $tenant_data['phone'];
        $params->sMrMrsAlt = '';
        $params->sFNameAlt = '';
        $params->sMIAlt = '';
        $params->sLNameAlt = '';
        $params->sAddr1Alt = '';
        $params->sAddr2Alt = '';
        $params->sCityAlt = '';
        $params->sRegionAlt = '';
        $params->sPostalCodeAlt = '';
        $params->sCountryAlt = '';
        $params->sPhoneAlt = '';
        $params->sMrMrsBus = '';
        $params->sFNameBus = '';
        $params->sMIBus = '';
        $params->sLNameBus = '';
        $params->sCompanyBus = '';
        $params->sAddr1Bus = '';
        $params->sAddr2Bus = '';
        $params->sCityBus = '';
        $params->sRegionBus = '';
        $params->sPostalCodeBus = '';
        $params->sCountryBus = '';
        $params->sPhoneBus = '';
        $params->sFax = $tenant_data['fax'];
        $params->sEmail = $tenant_data['email'];
        $params->sPager = '';
        $params->sMobile = '';
        $params->bCommercial = FALSE;
        $params->bCompanyIsTenant = FALSE;
        $params->dDOB = date('c', time());
        $params->sTenNote = '';
        $params->sLicense = '';
        $params->sLicRegion = '';
        $params->sSSN = '';

        try {
            $tenant = array();
            $data = $client->TenantNewDetailed($params);
            $result = $data->TenantNewDetailedResult;
            $xml_data = simplexml_load_string($result->any);
            $xml_data_rt = $xml_data->NewDataSet->RT;
            $xml_data_table = $xml_data->NewDataSet->Tenants;
            $tenant['data'] = $this->xml2array($xml_data_table);
            $tenant['rt'] = $this->xml2array($xml_data_rt);
            return $tenant;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage() . '<br />' . $e);
        }
    }

    public function add_reservation($reservation_data = array())
    {
        $client = new SoapClient(SITELINK_URL);
        $params = new stdClass();
        $params->sCorpCode = SITELINK_CORP_CODE;
        $params->sCorpUserName = SITELINK_CORP_LOGIN;
        $params->sCorpPassword = SITELINK_CORP_PASS;
        
        $params->sLocationCode = $reservation_data['lo_code'];
        $params->sTenantID = $reservation_data['tenant_id'];
        $params->sUnitID1 = $reservation_data['unit_id'];
        $params->sUnitID2 = '';
        $params->sUnitID3 = '';
        $params->dNeeded = $reservation_data['date'];
        $params->sComment = $reservation_data['comment'];
        $params->iSource = 5;

        try {
            $reservation = array();
            $data = $client->ReservationNewWithSource($params);
            $result = $data->ReservationNewWithSourceResult;
            $xml_data = simplexml_load_string($result->any);
            $xml_data_rt = $xml_data->NewDataSet->RT;
            $xml_data_table = $xml_data->NewDataSet->Tenants;
            $reservation['data'] = $this->xml2array($xml_data_table);
            $reservation['rt'] = $this->xml2array($xml_data_rt);
            return $reservation;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage() . '<br />' . $e);
        }
    }

    public function reservation_fee_retrieve($lo_code)
    {
         $client = new SoapClient(SITELINK_URL);
         $params = new stdClass();
         $params->sCorpCode = SITELINK_CORP_CODE;
         $params->sLocationCode = $lo_code;
         $params->sCorpUserName = SITELINK_CORP_LOGIN;
         $params->sCorpPassword = SITELINK_CORP_PASS;
         //$_SESSION['lo_code']= $lo_code;

        try {
            $reservation_fees = array();

            $data = $client->ReservationFeeRetrieve($params);
            $result = $data->ReservationFeeRetrieveResult;
            $xml_data = simplexml_load_string($result->any);
            $xml_data_table = $xml_data->NewDataSet->Table;
            if (count($xml_data_table) > 0) {
                foreach ($xml_data_table as $reservation_fee) {
                    $reservation_fees[] = $this->xml2array($reservation_fee);
                }
                return $reservation_fees;
            } else {
                return FALSE;
            }
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage() . '<br />' . $e);
        }
    }

    public function add_reservation_fee($reservation_fee_data = array())
    {
        $client = new SoapClient(SITELINK_URL);
        $params = new stdClass();
        $params->sCorpCode = SITELINK_CORP_CODE;
        
        $params->sCorpUserName = SITELINK_CORP_LOGIN;
        $params->sCorpPassword = SITELINK_CORP_PASS;
        $params->sLocationCode = $reservation_fee_data['lo_code'];
        $params->iTenantID = $reservation_fee_data['tenant_id'];
        $params->iWaitingListID = $reservation_fee_data['waiting_list_id'];
        $params->iCreditCardType = $reservation_fee_data['card_type'];
        $params->sCreditCardNumber = $reservation_fee_data['card_number'];
        $params->sCreditCardCVV = $reservation_fee_data['card_cvv'];
        $params->dExpirationDate = $reservation_fee_data['expiration_date'];
        $params->sBillingName = $reservation_fee_data['card_name'];
        $params->sBillingAddress = $reservation_fee_data['card_address'];
        $params->sBillingZipCode = $reservation_fee_data['card_postal'];
        $params->bTestMode = TRUE;

        try {
            $reservation_fee = array();
            $data = $client->ReservationFeeAdd($params);
            $result = $data->ReservationFeeAddResult;
            $xml_data = simplexml_load_string($result->any);
            $xml_data_rt = $xml_data->NewDataSet->RT;
            $xml_data_table = $xml_data->NewDataSet->Receipts;
            $reservation_fee['data'] = $this->xml2array($xml_data_table);
            $reservation_fee['rt'] = $this->xml2array($xml_data_rt);
            return $reservation_fee;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage() . '<br />' . $e);
        }
    }

    public function move_in_cost_retrieve($lo_code, $unit_id, $date)
    {   
         $client = new SoapClient(SITELINK_URL);
         $params = new stdClass();
         $params->sCorpCode = SITELINK_CORP_CODE;
         $params->sLocationCode = $lo_code;
         $params->sCorpUserName = SITELINK_CORP_LOGIN;
         $params->sCorpPassword = SITELINK_CORP_PASS;
         $params->iUnitID = $unit_id;
         $params->dMoveInDate = $date;
        try {
            $move_in_costs = array();
            $data = $client->MoveInCostRetrieve($params);
            $result = $data->MoveInCostRetrieveResult;
            $xml_data = simplexml_load_string($result->any);
            $xml_data_table = $xml_data->NewDataSet->Table;
            if (count($xml_data_table) > 0) {
                foreach ($xml_data_table as $move_in_cost) {
                    $move_in_costs[] = $this->xml2array($move_in_cost);
                }
                return $move_in_costs;
            } else {
                return FALSE;
            }
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage() . '<br />' . $e);
        }
    }

    public function move_in($move_in_data)
    {
        $client = new SoapClient(SITELINK_URL);
        $params = new stdClass();
        $params->sCorpCode = SITELINK_CORP_CODE;
        $params->sCorpUserName = SITELINK_CORP_LOGIN;
        $params->sCorpPassword = SITELINK_CORP_PASS;

        $params->sLocationCode = $move_in_data['lo_code'];
        $params->TenantID = $move_in_data['tenant_id'];
        $params->sAccessCode = $move_in_data['acc_id'];
        $params->UnitID = $move_in_data['unit_id'];
        $params->dStartDate = $move_in_data['start_date'];
        $params->dEndDate = $move_in_data['end_date'];
        $params->dcPaymentAmount = $move_in_data['amount'];
        $params->iCreditCardType = $move_in_data['card_type'];
        $params->sCreditCardNumber = $move_in_data['card_number'];
        $params->sCreditCardCVV = $move_in_data['card_cvv'];
        $params->dExpirationDate = $move_in_data['expiration_date'];
        $params->sBillingName = $move_in_data['card_name'];
        $params->sBillingAddress = $move_in_data['card_address'];
        $params->sBillingZipCode = $move_in_data['card_postal'];
        $params->bTestMode = TRUE;
        //return $params; die();
        try {
            $move_in = array();
            $data = $client->MoveIn($params);
            $result = $data->MoveInResult;
            $xml_data = simplexml_load_string($result->any);
            $xml_data_rt = $xml_data->NewDataSet->RT;
            $xml_data_table = $xml_data->NewDataSet->Receipts;
            $move_in['data'] = $this->xml2array($xml_data_table);
            $move_in['rt'] = $this->xml2array($xml_data_rt);
            return $move_in;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage() . '<br />' . $e);
        }
    }
    public function sendMail(){
            extract($_SESSION['data']);
            $rows = "";
                   $rows.= "<h3>Site Information</h3>";
                    foreach ($site_information as $index => $value) {
                        if (!is_array($value)) {
                            $rows .= "<tr>
                                        <td>$index</td>
                                        <td>$value</td>
                                    </tr>";
                             }
                         }

                   $rows.=  "
                        <table>
                            <tr>
                                <th style='text-align: left;'>#</th>
                                <th style='text-align: left;'>value</th>
                            </tr>
                            $rows
                        </table>
                        ";

                    $rows .=  "<br><br><hr><br><br>";
                   $rows .= "<h3>Unit Information</h3>";

                    $rows = "";
                    foreach ($unit_information as $index => $value) {
                        if (!is_array($value)) {
                            $rows .= "
                            <tr>
                                <td>$index</td>
                                <td>$value</td>
                            </tr>";
                        }
                    }

                    $rows .= "
                        <table>
                            <tr>
                                <th style='text-align: left;'>#</th>
                                <th style='text-align: left;'>value</th>
                            </tr>
                            $rows
                        </table>
                        ";
                     $to=SITELINK_EMAIL;
                     $subject='Regarding Your '.$_SESSION['type_text'];
                     $message=$rows;
                     $headers='Content-type:text/html;charset=UTF-8';
                     $attachments='';
                     wp_mail( $to, $subject, $message, $headers, $attachments );
                     
                return TRUE;
        }

}