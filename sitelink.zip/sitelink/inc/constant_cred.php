<?php
   			define( 'SITELINK_EMAIL', get_option('site_mail'));
			define( 'SITELINK_URL',get_option('site_url'));
		    define( 'SITELINK_CORP_CODE', get_option('site_corp_code') );
		    define( 'SITELINK_LOC_CODE', get_option('site_loc_code') );
		    define( 'SITELINK_CORP_LOGIN',get_option('site_corp_login') );
		    define( 'SITELINK_CORP_PASS', get_option('site_corp_pwd')); 
		    

		    /*define( 'SITELINK_URL', "https://api.smdservers.net/CCWs_3.5/CallCenterWs.asmx?WSDL");
		    define( 'SITELINK_CORP_CODE', "CCTST" );
		    define( 'SITELINK_LOC_CODE', "Demo" );
		    define( 'SITELINK_CORP_LOGIN', "Administrator:::DESIGN225Y76H4FJEW8K" );
		    define( 'SITELINK_CORP_PASS', "Demo" );*/